from scanner import scan_file
from detector import detect_threat

print("=" * 45)
print("      THREAT MONITORING SYSTEM")
print("=" * 45)

filename = input("Enter file name: ")

result = scan_file(filename)

if result is not None:

    content, ip, email, url = result

    threats = detect_threat(content)

    print("\n----- Extracted Data -----")

    print("\nIP Address:")
    for i in ip:
        print(i)

    print("\nEmail:")
    for e in email:
        print(e)

    print("\nURL:")
    for u in url:
        print(u)

    print("\n----- Threats Detected -----")

    if len(threats) == 0:
        print("No Threat Found")

    else:
        for t in threats:
            print(t)

    print("\n----- Summary -----")

    print("Total IPs      :", len(ip))
    print("Total Emails   :", len(email))
    print("Total URLs     :", len(url))
    print("Threats Found  :", len(threats))