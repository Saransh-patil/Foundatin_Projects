def detect_threat(content):

    threats = []

    with open("threat_rules.txt", "r") as file:
        rules = file.readlines()

    for rule in rules:

        rule = rule.strip()

        if rule.lower() in content.lower():
            threats.append(rule)

    return threats