import re

def scan_file(filename):

    try:
        with open(filename, "r") as file:
            content = file.read()

    except FileNotFoundError:
        print("File not found!")
        return None

    # Extract IP Address
    ip = re.findall(r"\b(?:\d{1,3}\.){3}\d{1,3}\b", content)

    # Extract Email
    email = re.findall(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}", content)

    # Extract URL
    url = re.findall(r"https?://[^\s]+", content)

    return content, ip, email, url